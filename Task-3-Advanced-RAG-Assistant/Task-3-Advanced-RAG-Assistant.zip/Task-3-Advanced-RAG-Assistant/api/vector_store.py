
import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

class VectorStore:
    def __init__(self, model_name="sentence-transformers/all-MiniLM-L6-v2"):
        self.model = SentenceTransformer(model_name)
        self.index = None
        self.chunks = []

    def build(self, chunks):
        if not chunks:
            raise ValueError("Cannot index an empty document.")

        self.chunks = list(chunks)
        embeddings = self.model.encode(
            self.chunks,
            normalize_embeddings=True,
            convert_to_numpy=True
        ).astype("float32")

        self.index = faiss.IndexFlatIP(embeddings.shape[1])
        self.index.add(embeddings)
        return len(self.chunks)

    def search(self, question, top_k=3):
        if self.index is None:
            raise RuntimeError("Build the index before searching.")

        query_vector = self.model.encode(
            [question],
            normalize_embeddings=True,
            convert_to_numpy=True
        ).astype("float32")

        k = min(top_k, len(self.chunks))
        scores, indices = self.index.search(query_vector, k)

        return [
            {"text": self.chunks[int(i)], "score": float(score)}
            for score, i in zip(scores[0], indices[0])
            if i >= 0
        ]
