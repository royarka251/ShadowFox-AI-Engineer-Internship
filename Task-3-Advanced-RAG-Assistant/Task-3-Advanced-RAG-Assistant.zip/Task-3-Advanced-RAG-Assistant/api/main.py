
from pathlib import Path
from tempfile import NamedTemporaryFile
from threading import Lock

from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel, Field

from api.ingestion import extract_text, chunk_text
from api.vector_store import VectorStore
from api.qa import GroundedQA

app = FastAPI(
    title="Advanced RAG Assistant API",
    version="1.0.0",
    description="Document-grounded question answering."
)

store = VectorStore()
qa_model = None
document_loaded = False
qa_lock = Lock()

class QuestionRequest(BaseModel):
    question: str = Field(min_length=1, max_length=1000)

@app.get("/")
def health():
    return {
        "status": "running",
        "service": "Advanced RAG Assistant"
    }

@app.post("/upload")
async def upload_document(file: UploadFile = File(...)):
    global document_loaded

    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in {".pdf", ".txt", ".md"}:
        raise HTTPException(
            status_code=400,
            detail="Only PDF, TXT and Markdown files are supported."
        )

    data = await file.read()

    if not data:
        raise HTTPException(status_code=400, detail="Uploaded file is empty.")

    if len(data) > 20 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Maximum file size is 20 MB.")

    temp_path = None
    try:
        with NamedTemporaryFile(
            suffix=suffix, delete=False
        ) as temp:
            temp.write(data)
            temp_path = Path(temp.name)

        text = extract_text(temp_path)
        chunks = chunk_text(text, chunk_size=800, overlap=120)

        if not chunks:
            raise HTTPException(
                status_code=422,
                detail="No readable text found in the document."
            )

        store.build(chunks)
        document_loaded = True

        return {
            "filename": Path(file.filename).name,
            "characters_extracted": len(text),
            "chunks_indexed": len(chunks),
            "message": "Document uploaded and indexed successfully."
        }

    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    finally:
        if temp_path and temp_path.exists():
            temp_path.unlink(missing_ok=True)
        await file.close()

@app.post("/ask")
def ask_question(request: QuestionRequest):
    global qa_model

    if not request.question.strip():
        raise HTTPException(status_code=400, detail="Question cannot be blank.")

    if not document_loaded:
        raise HTTPException(
            status_code=400,
            detail="Upload a document before asking questions."
        )

    try:
        with qa_lock:
            if qa_model is None:
                qa_model = GroundedQA()

            result = qa_model.answer(
                request.question.strip(), store, top_k=3
            )

        return {
            "question": request.question,
            "answer": result["answer"],
            "sources": result["sources"]
        }

    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
