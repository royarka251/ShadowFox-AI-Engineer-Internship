
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

class GroundedQA:
    def __init__(self, model_name="google/flan-t5-small"):
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_name)

        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.model.to(self.device)
        self.model.eval()

    def answer(self, question, vector_store, top_k=3):
        results = vector_store.search(question, top_k=top_k)

        if not results:
            return {
                "answer": "The answer was not found in the uploaded documents.",
                "sources": []
            }

        context = "\n\n".join(item["text"] for item in results)

        prompt = (
            "Answer using only the context below. "
            "If the answer is absent, say that it was not found "
            "in the uploaded documents.\n\n"
            f"Context:\n{context}\n\n"
            f"Question: {question}\nAnswer:"
        )

        inputs = self.tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        ).to(self.device)

        with torch.no_grad():
            output = self.model.generate(
                **inputs,
                max_new_tokens=100,
                do_sample=False
            )

        generated = self.tokenizer.decode(
            output[0], skip_special_tokens=True
        ).strip()

        return {
            "answer": generated,
            "sources": results
        }
