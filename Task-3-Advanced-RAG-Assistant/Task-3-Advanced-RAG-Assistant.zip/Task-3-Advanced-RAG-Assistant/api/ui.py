
import streamlit as st
import requests

st.set_page_config(
    page_title="Advanced RAG Assistant",
    page_icon="📚",
    layout="wide"
)

st.title("Advanced RAG Document Assistant")
st.caption("Upload a document and ask questions grounded in its content.")

API_URL = "http://127.0.0.1:8000"

uploaded_file = st.file_uploader(
    "Upload a document",
    type=["pdf", "txt", "md"]
)

if uploaded_file is not None:
    if st.button("Upload and index document"):
        try:
            response = requests.post(
                f"{API_URL}/upload",
                files={
                    "file": (
                        uploaded_file.name,
                        uploaded_file.getvalue(),
                        uploaded_file.type or "application/octet-stream"
                    )
                },
                timeout=180
            )
            response.raise_for_status()
            st.session_state["document_ready"] = True
            st.success("Document indexed successfully.")
            st.json(response.json())
        except requests.RequestException as exc:
            st.error(f"Upload failed: {exc}")

question = st.text_input(
    "Ask a question",
    max_chars=1000,
    placeholder="What does the document say?"
)

if st.button("Submit question"):
    if not st.session_state.get("document_ready", False):
        st.warning("Upload and index a document first.")
    elif not question.strip():
        st.warning("Please enter a question.")
    else:
        try:
            with st.spinner("Searching the document..."):
                response = requests.post(
                    f"{API_URL}/ask",
                    json={"question": question.strip()},
                    timeout=180
                )
                response.raise_for_status()
                result = response.json()

            st.subheader("Answer")
            st.write(result["answer"])

            st.subheader("Retrieved sources")
            for index, source in enumerate(result.get("sources", []), 1):
                with st.expander(f"Source {index}"):
                    st.write(source.get("text", ""))
                    if "score" in source:
                        st.write(f"Similarity score: {source['score']:.3f}")

        except requests.RequestException as exc:
            st.error(f"Question request failed: {exc}")
